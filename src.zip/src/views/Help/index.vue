<template>
  <div>
    帮助页面
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  }
}
</script>

<style lang='less' type='text/css'>

</style>
