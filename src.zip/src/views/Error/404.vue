<template>
  <h1>您的权限不够，请联系超级管理员提升权限</h1>
</template>

<script>
export default {
  name: '404',
  data () {

  }
}
</script>

<style>

</style>
